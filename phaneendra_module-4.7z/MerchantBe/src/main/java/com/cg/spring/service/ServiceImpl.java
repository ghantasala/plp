package com.cg.spring.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.beans.MerchantInfo;
import com.cg.spring.beans.MerchantOrders;
import com.cg.spring.repo.IMerchantOrdersRepo;
import com.cg.spring.repo.IMerchantRepo;

@Service
public class ServiceImpl implements IService{
	@Autowired
	private IMerchantRepo repo;
	@Autowired
	private IMerchantOrdersRepo ordersrepo;
	public  Optional<MerchantInfo> displayInfo(String email) {
		return repo.findById(email);
		
		
	}
	@Override
	public List<MerchantOrders> displayorders(String email) {
		
		return ordersrepo.displayorders(email);
	}
	
}
