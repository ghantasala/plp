package com.cg.spring.repo;

import org.springframework.stereotype.Repository;

@Repository
public class MerchantProductsRepo implements IProductsRepo{

}
