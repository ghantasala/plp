package com.cg.spring.repo;

public interface IProductsRepo {

}
