package com.cg.spring.repo;

public interface IIMerchantInventoryRepo {

}
