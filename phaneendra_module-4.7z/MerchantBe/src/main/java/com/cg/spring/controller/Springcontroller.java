package com.cg.spring.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.spring.beans.MerchantInfo;
import com.cg.spring.beans.MerchantOrders;
import com.cg.spring.service.IService;

@RestController
public class Springcontroller {
	static MerchantInfo merchant; 
	@Autowired
	IService service;
	@RequestMapping("/profile")
	public Optional<MerchantInfo> displayprofile() {
		String email="abcd@gmail.com";
		return service.displayInfo(email);
	
	}
	@RequestMapping("/orders")
	public List<MerchantOrders> displayorders(){
		String email="phani@gmail.com";
		return service.displayorders(email);
	}

}
