package com.cg.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.spring.beans.Customer;
@Repository
public interface CustomerRepo extends CrudRepository<Customer,Integer> {



}
