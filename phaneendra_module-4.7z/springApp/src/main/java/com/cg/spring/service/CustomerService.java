package com.cg.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.repo.CustomerRepo;
import com.cg.spring.beans.Customer;

@Service
public class CustomerService implements ICustomerService  {
	@Autowired
	CustomerRepo repo;

	@Override
	public List<Customer> ShowAll() {
		
		return (List<Customer>) repo.findAll();
	}

}
